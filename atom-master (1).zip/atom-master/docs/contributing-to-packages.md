See http://flight-manual.atom.io/hacking-atom/sections/contributing-to-official-atom-packages/
