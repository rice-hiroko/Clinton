1;
2;
function f3() {
  return 4;
};
6;
7;
function f8() {
  return 9;
};
11;
12;
