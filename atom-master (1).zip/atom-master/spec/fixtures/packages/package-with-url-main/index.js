module.exports = function initialize() {
  global.reachedUrlMain = true;
  return Promise.resolve();
};
