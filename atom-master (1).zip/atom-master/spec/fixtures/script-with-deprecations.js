require('fs').existsSync('hi');
process.stdout.write('hi');
