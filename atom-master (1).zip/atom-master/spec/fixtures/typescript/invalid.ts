var foo = 123 123; // Syntax error
