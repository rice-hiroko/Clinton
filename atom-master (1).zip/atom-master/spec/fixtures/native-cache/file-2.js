module.exports = function () { return 2; }
