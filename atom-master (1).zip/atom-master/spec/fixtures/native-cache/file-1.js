module.exports = function () { return 1; }
