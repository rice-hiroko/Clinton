This folder is where [apm](https://github.com/atom/apm) is installed to so that
it is bundled with Atom.
